$(function() {
    $('#submit').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadform')[0]);
        var dochash=$('#hash').val();
        $.ajax({
            type: 'POST',
            url: '/uploadajax',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#imessage").text('upload success');       
            $("#resultFilename").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
            $("#resultBlockchain").text(data['prt']);
        }).fail(function(data){
            alert('error!');
        });
    });
}); 
$(function() {
    $('#submittwo').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadformtwo')[0]);
        var dochash=$('#hash').val();
        $.ajax({
            type: 'POST',
            url: '/uploadajax2',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#imessage").text('upload success');       
            $("#resultFilename").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
        }).fail(function(data){
            alert('error!');
        });
    });
}); 
$(function() {
    $('#submithree').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadformthree')[0]);
        $.ajax({
            type: 'POST',
            url: '/uploadajax3',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#imessage").text('upload success');
            $("#resultFilename").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
        }).fail(function(data){
            alert('error!');
        });
    });
}); 
$(function() {
    $('#submitfour').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadformfour')[0]);
        $.ajax({
            type: 'POST',
            url: '/uploadajax4',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#imessage").text('upload success');
            $("#resultFilename").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
        }).fail(function(data){
            alert('error!');
        });
    });
}); 
$(function() {
    $('#submitfive').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadformfive')[0]);
        $.ajax({
            type: 'POST',
            url: '/uploadajax5',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#imessage").text('upload success');
            $("#resultFilename").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
        }).fail(function(data){
            alert('error!');
        });
    });
}); 
$(function() {
    $('#submitfileone').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadformfile')[0]);
        $.ajax({
            type: 'POST',
            url: '/uploadajaxfileone',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#smessage").text('upload success');
            $("#resultFilenames").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
        }).fail(function(data){
            alert('error!');
        });
    });
}); 
$(function() {
    $('#submitfiletwo').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadformfiletwo')[0]);
        $.ajax({
            type: 'POST',
            url: '/uploadajaxfiletwo',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#smessage").text('upload success');
            $("#resultFilenames").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
        }).fail(function(data){
            alert('error!');
        });
    });
}); 
$(function() {
    $('#submitfilethree').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadformfilethree')[0]);
        $.ajax({
            type: 'POST',
            url: '/uploadajaxfilethree',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#smessage").text('upload success');
            $("#resultFilenames").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
        }).fail(function(data){
            alert('error!');
        });
    });
}); 
$(function() {
    $('#submitmainimage').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadformmainimage')[0]);
        $.ajax({
            type: 'POST',
            url: '/uploadajaxmainimage',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#imessage").text('upload success');       
            $("#resultFilename").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
            $("#resultBlockchain").text(data['prt']);
        }).fail(function(data){
            alert('error!');
        });
    });
});  
$(function() {
    $('#submitnew').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadnewformmainimage')[0]);
        $.ajax({
            type: 'POST',
            url: '/uploadajaxnewmainimage',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#imessage").text('upload success');       
            $("#resultFilename").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
            $("#resultBlockchain").text(data['prt']);
        }).fail(function(data){
            alert('error!');
        });
    });
});  
$(function() {
    $('#submitedit').click(function() {
        event.preventDefault();
        var form_data = new FormData($('#uploadeditformmainimage')[0]);
        $.ajax({
            type: 'POST',
            url: '/uploadajaxeditmainimage',
            data: form_data,
            contentType: false,
            processData: false,
            dataType: 'json'
        }).done(function(data, textStatus, jqXHR){
            console.log(data);
            console.log(textStatus);
            console.log(jqXHR);
            console.log('Success!');
            $("#imessage").text('upload success');       
            $("#resultFilename").text(data['name']+" upload success");
            $("#resultFilesize").text(data['size']);
            $("#resultBlockchain").text(data['prt']);
        }).fail(function(data){
            alert('error!');
        });
    });
});  
