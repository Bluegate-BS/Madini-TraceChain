from flask_login import UserMixin
from __init__ import db

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True) # primary keys are required by SQLAlchemy
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    name = db.Column(db.String(1000))

class Verif(db.Model):
   bhash = db.Column(db.VARCHAR(200))
   mid = db.Column(db.VARCHAR(200))
   thash = db.Column(db.VARCHAR(200))
   sku = db.Column(db.VARCHAR(200))
   pname = db.Column(db.VARCHAR(200))
   mainimage = db.Column(db.VARCHAR(200))
   id = db.Column(db.Integer, primary_key=True) # primary keys are required by SQLAlchemy
 



def __init__(self, bhash, mid, thash, sku, pname, mainimage, id):
   self.bhash = bhash
   self.mid = mid
   self.thash = thash
   self.sku = sku
   self.pname = pname
   self.mainimage = mainimage
   self.id = id
 